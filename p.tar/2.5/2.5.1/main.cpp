#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include<iostream>
using namespace std;

int main() {
    Point *p1 = new Point();
    Point *p2 = new Point(3,5);
    Point *p3 = new Point(*p1);
    cout << p1->Distance(*p2) << endl;

    delete p1;
    delete p2;
    delete p3;


    int size;
    cout << "Please input the size of the array:";
    cin >> size;
    Point* parray = new Point[size];
    cout << parray[1] << endl;
    delete []parray;

    return 0;
}

