#include "Point.h"
#include "Array.h"

#include<iostream>
using namespace std;

int main() {
    Array arr(10);
    Point p(1,2.33);
    arr.SetElement(2,p);
    cout << arr.GetElement(2) << endl;
    return 0;
}

