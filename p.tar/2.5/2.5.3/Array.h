#ifndef _ARRAY_H
#define _ARRAY_H
#include "Point.h"
class Array {
    public:
        Array();
        Array(int size);
        Array(const Array& source);
        ~Array();
        int Size() const; //get array size
        void SetElement(int index, const Point& p);
        Point& GetElement(int index); //get one point at index
        Point& operator [] (int index); //get one point at index
        const Point& operator [] (int index) const; //useful when the array is const
        Array& operator = (const Array& source); // Assignment Operator
    private:
        Point* m_data;
        int m_size;
};

#endif
