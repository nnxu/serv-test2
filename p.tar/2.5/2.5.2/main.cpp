#include "Point.h"
#include<iostream>
using namespace std;

int main() {
    Point** parray = new Point*[3];
    for(int i = 0; i < 3; ++i ) {
        parray[i] = new Point(i+1, 5);
        cout << *(parray[i]) << endl;
    }

    for(int i = 0; i < 3; ++i ) {
        delete parray[i];
    }
    delete []parray;

    return 0;
}

