#include <stdio.h>
int main()
{
    int a;
    printf("Please input a number to shift: \n");
    scanf("%d", &a);
    if(a>0) {
        printf("this is the same for logic and arithmetic shift: %d\n",  a>>2);
    } else {
        printf("this is arithmetic shift: %d\n",  a>>2);
    }

    return 0;
}
