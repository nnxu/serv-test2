#include <stdio.h>
int main()
{
    int a = 6;
    int b = 6;
    printf("a=6, show --a and a: %d %d\n", --a, a);
    printf("b=6, show b-- and b: %d %d\n", b--, b);
    return 0;
}
