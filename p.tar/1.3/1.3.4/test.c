#include <stdio.h>
int main()
{
    int a = 0;
    a? printf("married\n") : printf("not married\n");
    int b = 5;
    b? printf("married\n") : printf("not married\n");
    return 0;
}
