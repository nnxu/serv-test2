#include <stdio.h>

void pprint() {
    printf("My first C-program\n");
    printf("is a fact!\n");
    printf("Good, isn't it?\n");
}
