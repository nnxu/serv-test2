#include "hello.h"

int main() {
    tri_surface();
    return 0;
}

