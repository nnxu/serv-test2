#include <stdio.h>

void tri_surface() {
    double base = 0.0, height = 0.0;
    printf("Please input the base of the triangle:");
    scanf("%lf", &base);
    printf("Please input the height of the triangle:");
    scanf("%lf", &height);
    printf("The surface of the triangle is %.2lf\n", (base*height)/2);
}
