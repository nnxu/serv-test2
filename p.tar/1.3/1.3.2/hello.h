#ifndef HELLO_HPP
#define HELLO_HPP

void tri_surface();

#endif
