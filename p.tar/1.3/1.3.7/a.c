#include <stdio.h>
#include <limits.h>

    int main()
{
    int a=0, b=0;

    if (a<b) a=10; b=20;

    printf("%d, %d\n", a, b);
    }
