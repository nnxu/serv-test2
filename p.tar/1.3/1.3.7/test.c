#include <stdio.h>
int main()
{
    int number = 0;
    int power = 0;
    int i;
    printf("Please input the number to multiply:");
    scanf("%d", &number); 
    printf("Please input the power:");
    scanf("%d", &power); 
    int result = 1;
    while(power > 0) {
        result <<= 1;
        --power;
    }
    printf("the result is %d", result*number);
    
    return 0;
}
