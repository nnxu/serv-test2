#ifndef _STACK_CPP
#define _STACK_CPP
#include<iostream>
#include "Stack.h"
using namespace std;
namespace MyName { namespace Containers {

template <class T>
Stack<T>& Stack<T>::operator = (const Stack<T>& source) {
    m_array = source.m_array;
    m_current = source.m_current;
}

template <class T>
void Stack<T>::Push(const T& element) {
    m_array.SetElement(m_current+1, element);
    ++m_current;
}
template <class T>
T& Stack<T>::Pop() {
    T& element = m_array.GetElement(m_current);
    --m_current;
    return element;
}

}}
#endif

