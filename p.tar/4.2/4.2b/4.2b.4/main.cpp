#include "Point.h"
#include "Stack.h"
#include<iostream>
using namespace std;
using namespace MyName::CAD;
using namespace MyName::Containers;

int main() {
    Stack<int> aa;
    aa.Push(5);
    aa.Push(6);
    cout << aa.Pop() << endl;
    return 0;
}

