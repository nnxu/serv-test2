#ifndef _STACK_H
#define _STACK_H
#include "Array.h"
namespace MyName { namespace Containers {

template <class T>
class Stack {
    public:
        Stack() : m_current(-1) {}
        Stack(int size) : m_array(size), m_current(-1) {}
        Stack(const Stack<T>& source) : Array<T>(source.m_array), m_current(source.m_current) {}
        Stack<T>& operator = (const Stack<T>& source); 
        void Push(const T& element);
        T& Pop();
    private:
        int m_current;
        Array<T> m_array;
};
}}
#ifndef _STACK_CPP
#include "Stack.cpp"
#endif
#endif
