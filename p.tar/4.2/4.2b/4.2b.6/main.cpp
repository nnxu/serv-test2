#include "Stack.h"
#include<iostream>
#include "StackException.h"
using namespace std;
using namespace MyName::Containers;

int main() {
    try {
        Stack<int, 4> aa;
        aa.Push(5);
        aa.Push(6);
        cout << aa.Pop() << endl;
        cout << aa.Pop() << endl;
        cout << aa.Pop() << endl;
    } catch(const StackEmptyException& e) {
        cout << e.GetMessage() << endl;
    } catch(const StackException& e) {
        cout << e.GetMessage() << endl;
    } catch(...) {
        cout << "here" << endl;
    }
    return 0;
}

