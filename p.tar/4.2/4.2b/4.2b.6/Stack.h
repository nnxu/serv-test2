#ifndef _STACK_H
#define _STACK_H
#include "Array.h"
namespace MyName { namespace Containers {

template <class T, int size>
class Stack {
    public:
        Stack() : m_array(size), m_current(-1) {}
        Stack(const Stack<T, size>& source) : Array<T>(source.m_array), m_current(source.m_current) {}
        Stack<T,size>& operator = (const Stack<T,size>& source); 
        void Push(const T& element);
        T& Pop();
    private:
        int m_current;
        Array<T> m_array;
};
}}
#ifndef _STACK_CPP
#include "Stack.cpp"
#endif
#endif
