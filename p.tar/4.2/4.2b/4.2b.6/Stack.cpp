#ifndef _STACK_CPP
#define _STACK_CPP
#include<iostream>
#include "Stack.h"
#include "StackFullException.h"
#include "StackEmptyException.h"
using namespace std;
namespace MyName { namespace Containers {

template <class T, int size>
Stack<T,size>& Stack<T,size>::operator = (const Stack<T,size>& source) {
    m_array = source.m_array;
    m_current = source.m_current;
}

template <class T, int size>
void Stack<T,size>::Push(const T& element) {
    try {
        m_array.SetElement(m_current+1, element);
        ++m_current;
    } catch (OutOfBoundsException& e) {
        throw StackFullException();
    }
}
template <class T, int size>
T& Stack<T,size>::Pop() {
    try {
        T& element = m_array.GetElement(m_current);
        --m_current;
        return element;
    } catch (OutOfBoundsException& e) {
        m_current = -1;
        throw StackEmptyException(); 
    }
}

}}
#endif

