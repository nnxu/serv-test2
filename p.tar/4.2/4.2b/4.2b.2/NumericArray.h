#ifndef _NUMERICARRAY_H
#define _NUMERICARRAY_H
#include "Array.h"

namespace MyName { namespace Containers {
template <class T>
class NumericArray : public Array<T> {
    public:
        NumericArray() : Array<T>() {}
        NumericArray(int size) : Array<T>(size) { }
        NumericArray(const NumericArray<T>& source) : Array<T>(source)  { }
        NumericArray<T>& operator = (const NumericArray<T>& source); // Assignment Operator
        NumericArray<T> operator * (double factor);
        NumericArray<T> operator + (NumericArray<T>& na) ;
        double DotProduct(NumericArray<T>& na);
    private:

};
}}
#ifndef _NUMERICARRAY_CPP
#include "NumericArray.cpp"
#endif
#endif
