#include "Point.h"
#include "NumericArray.h"
#include<iostream>
using namespace std;
using namespace MyName::CAD;
using namespace MyName::Containers;

int main() {
    NumericArray<double> arr1;
    NumericArray<double> arr2;
    cout << arr1.DotProduct(arr2) << endl;

    return 0;
}

