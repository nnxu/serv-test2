#ifndef _ARRAY_CPP
#define _ARRAY_CPP
#include "Array.h"
#include <iostream>

#include "OutOfBoundsException.h"
using namespace std;

namespace MyName { namespace Containers {

template <class T>
int Array<T>::m_default_size = 10;

template <class T>
int Array<T>::DefaultSize() {
    return m_default_size;
}
template <class T>
void Array<T>::DefaultSize(int size) {
    m_default_size = size;
}

template <class T>
Array<T>::Array() {
    m_data = new T[m_default_size];
    m_size = m_default_size;
}
template <class T>
Array<T>::Array(int size) {
    m_data = new T[size];
    m_size = size;
}

template <class T>
Array<T>::Array(const Array<T>& source) {
    m_data = new T[source.m_size];
    m_size = source.m_size;
    for(int i = 0; i < m_size; ++i) {
        m_data[i] = source.m_data[i];
    }
}

template <class T>
Array<T>::~Array() {
    delete []m_data;
    m_size = 0;
}
template <class T>
int Array<T>::Size() const {
    return m_size;
}

template <class T>
void Array<T>::SetElement(int index, const T& p) {
    if(index < 0 || index >= m_size) {
        throw OutOfBoundsException(index);
    }
    m_data[index] = p; 
}
template <class T>
T& Array<T>::GetElement(int index){
    if(index < 0 || index >= m_size) {
        throw OutOfBoundsException(index);
    }
    return m_data[index];
}

template <class T>
T& Array<T>::operator [] (int index) {
    return GetElement(index);
}

template <class T>
const T& Array<T>::operator [] (int index) const{
    if(index >= 0 && index < m_size) {
        return m_data[index];
    }
    return m_data[0];
}

template <class T>
Array<T>& Array<T>::operator = (const Array<T>& source) {
    if(this != &source) {
        delete []m_data;

        m_data = new T[source.m_size];
        m_size = source.m_size;
        for(int i = 0; i < m_size; ++i) {
            m_data[i] = source.m_data[i];
        }
    }
    return *this;
}
}}
#endif

