#ifndef _NUMERICARRAY_CPP
#define _NUMERICARRAY_CPP
#include<iostream>
using namespace std;
#include "NumericArray.h"
#include "OutOfBoundsException.h"
namespace MyName { namespace Containers {

template <class T>
NumericArray<T>& NumericArray<T>::operator = (const NumericArray<T>& source) {
    if(this != &source) {
        Array<T>::operator=(source);
    }
    return *this;
}
template <class T>
 NumericArray<T>  NumericArray<T>::operator * (double factor) {
     for(int i = 0 ; i < this->m_size; ++i) {
         this->m_data[i] *= 2;
     }
}
template <class T>
NumericArray<T> NumericArray<T>::operator + (NumericArray<T>& na) {
    if(this->m_size != na.m_size) {
        throw OutOfBoundsException();
    }
    NumericArray<T> result(this->Size());
    for(int i = 0 ; i < this->Size(); ++i) {
        result.SetElement(i, this->GetElement(i)+na.GetElement(i));
    }
    return result;
}
template <class T>
double NumericArray<T>::DotProduct(NumericArray<T>& na){
    if(this->Size() != na.Size()) {
        throw OutOfBoundsException(1);
    }
    
    double result = 0.0;
    for(int i = 0 ; i < this->Size(); ++i) {
        result += (this->GetElement(i) * na.GetElement(i));
    }
    return result;
}

}}
#endif

