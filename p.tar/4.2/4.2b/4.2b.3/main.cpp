#include "Point.h"
#include "PointArray.h"
#include<iostream>
using namespace std;
using namespace MyName::CAD;
using namespace MyName::Containers;

int main() {
    PointArray arr;
    Point p1(3,4);
    arr.SetElement(0, p1);
    cout << arr.Length() << endl;
    return 0;
}

