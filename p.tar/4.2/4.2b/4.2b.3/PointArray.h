#ifndef _POINTARRAY_H
#define _POINTARRAY_H
#include "Point.h"
#include "Array.h"
using MyName::CAD::Point;
namespace MyName { namespace Containers {

class PointArray : public Array<Point> {
    public:
        PointArray() : Array<Point>() {}
        PointArray(int size) : Array<Point>() {}
        PointArray(const PointArray& source) : Array<Point>(source)  {}
        //~PointArray() {}
        PointArray& operator = (const PointArray& source);
        double Length();
};
}}
#endif
