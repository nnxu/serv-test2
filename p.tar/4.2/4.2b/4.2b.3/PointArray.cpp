#include<iostream>
#include "PointArray.h"
using MyName::CAD::Point;
namespace MyName { namespace Containers {
PointArray& PointArray::operator = (const PointArray& source) {
    if(this != &source) {
        Array<Point>::operator=(source);
    }
    return *this;
}
double PointArray::Length() {
    double result = 0.0;
    for(int i = 0; i < this->Size(); ++i) {
        result += this->GetElement(i).Distance();
    }
    return result;
}

}}

