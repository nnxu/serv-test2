#ifndef _ARRAY_H
#define _ARRAY_H
namespace MyName { namespace Containers {

template <class T>
class Array {
    public:
        Array();
        Array(int size);
        Array(const Array<T>& source);
        ~Array();
        int Size() const;
        void SetElement(int index, const T& p);
        T& GetElement(int index);
        T& operator [] (int index);
        const T& operator [] (int index) const; //useful when the array is const
        Array<T>& operator = (const Array<T>& source); // Assignment Operator
        static int DefaultSize();
        static void DefaultSize(int size);
    private:
        static int m_default_size;
        T* m_data;
        int m_size;
};
}}
#ifndef _ARRAY_CPP
#include "Array.cpp"
#endif
#endif
