#ifndef _STACKEMPTYEXCEPTION_H
#define _STACKEMPTYEXCEPTION_H
#include <string>
#include "StackException.h"
class StackEmptyException : StackException {
    public:
        virtual std::string GetMessage() const { return "Stack Empty!"; }
};
#endif
