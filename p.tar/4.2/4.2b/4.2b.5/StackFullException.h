#ifndef _STACKFULLEXCEPTION_H
#define _STACKFULLEXCEPTION_H
#include <string>
#include "StackException.h"
class StackFullException : public StackException {
    public:
        virtual std::string GetMessage() const { return "Stack Full!"; }
};
#endif
