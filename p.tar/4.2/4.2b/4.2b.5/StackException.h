#ifndef _STACKEXCEPTION_H
#define _STACKEXCEPTION_H
#include <string>
class StackException {
    public:
        virtual std::string GetMessage() const { return "StackException!"; }

};
#endif
