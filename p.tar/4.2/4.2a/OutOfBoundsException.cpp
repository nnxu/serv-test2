#include<iostream>
#include "OutOfBoundsException.h"
using namespace std;

std::string OutOfBoundsException::GetMessage() {
    std::stringstream ss;
    ss << "The given index " << m_e << " is out of bounds";
    return ss.str();
}

