#ifndef _OUTOFBOUNDSEXCEPTION_H
#define _OUTOFBOUNDSEXCEPTION_H
#include <sstream>
#include <string>
#include "ArrayException.h"
class OutOfBoundsException : public ArrayException {
    public:
        OutOfBoundsException(int e) : m_e(e) { }
        std::string GetMessage();
    private:
        int m_e;
};

#endif
