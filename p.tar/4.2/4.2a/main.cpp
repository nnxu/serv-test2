#include "Point.h"
#include "Array.h"
//#include "Array.cpp"
#include<iostream>
using namespace std;
using namespace MyName::CAD;
using namespace MyName::Containers;

int main() {
    Array<Point> points(5);
    Point p = points.GetElement(4);
    return 0;
}

