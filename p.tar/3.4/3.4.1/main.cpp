//#include "Point.h"
//#include "Array.h"
#include "Line.h"
//#include "Circle.h"

#include<iostream>
using namespace std;
using MyName::CAD::Line;

int main() {
    Line l;
    return 0;
}

