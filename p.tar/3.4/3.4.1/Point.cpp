#include <sstream>
#include <cmath>
#include <iostream>
#include "Point.h"
using namespace std;
namespace MyName { namespace CAD {

Point::~Point() {
    std::cout << "Point default destructor \n";
}

std::string Point::ToString() const {
    std::stringstream ss;
    ss << "(" << m_x << "," << m_y << ")";
    return ss.str();
}

double Point::Distance() const {
    return std::sqrt(m_x * m_x + m_y * m_y);
}

double Point::Distance(const Point& p) const {
    //p.SetX(5); try to change to const p, but compile failed! 
    return std::sqrt((m_x-p.m_x)*(m_x-p.m_x) + (m_y-p.m_y)*(m_y-p.m_y));
}

Point Point::operator - () const{
    return Point(m_x*(-1), m_y*(-1));
}
Point Point::operator * (double factor) const {
    return Point(m_x*factor, m_y*factor);
}
Point Point::operator + (const Point& p) const {
    return Point(m_x+p.m_x, m_y+p.m_y);
}

bool Point::operator == (const Point& p) const {
    return m_x == p.m_x && m_y == p.m_y;
}

Point& Point::operator = (const Point& source) {
    std::cout << "Point assign operator \n";
    if(this != &source) {
        m_x = source.m_x;
        m_y = source.m_y;
    }
    return *this;
}

Point& Point::operator *= (double factor) {
    m_x *= factor;
    m_y *= factor;
    return *this;
}

ostream& operator << (ostream& os, const Point& p) {
    os << "(" << p.m_x << "," << p.m_y << ")";
    return os;
}
}}
