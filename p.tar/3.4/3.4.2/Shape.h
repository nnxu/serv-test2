#ifndef _SHAPE_H
#define _SHAPE_H
#include <string>
namespace MyName { namespace CAD { 
class Shape {
    public:
        Shape();
        Shape(const Shape& source) : m_id(source.m_id) { }
        Shape operator = (const Shape& source); // Assignment Operator
        std::string ToString() const;
        int ID() const;
    private:
        int m_id;
};
}}
#endif
