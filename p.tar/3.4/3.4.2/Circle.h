#ifndef _CIRCLE_H
#define _CIRCLE_H
#include "Point.h"
#include <string>
#define M_PI 3.1415926
namespace MyName { namespace CAD {

class Circle {
    public:
        Circle() : m_center(0,0), m_radius(0.00) { }
        Circle(const Point& p, double radius) : m_center(p), m_radius(radius) { }
        Circle(const Circle& c) : m_center(c.m_center), m_radius(c.m_radius) { }
        ~Circle();
        Point CenterPoint() const;
        Point CenterPoint(const Point& p);
        double Radius() const;
        double Radius(double radius);
        double Diameter() const;
        double Area() const;
        double Circumference() const;
        std::string ToString() const;
        Circle operator = (const Circle& source); // Assignment Operator
        friend ostream& operator << (ostream& os, const Circle& c); // Send to ostream
    private:
        Point m_center;
        double m_radius;
};
}}
#endif
