#ifndef _ARRAY_H
#define _ARRAY_H
#include "Point.h"
namespace MyName { namespace Containers {

class Array {
    public:
        Array();
        Array(int size);
        Array(const Array& source);
        ~Array();
        int Size() const;
        void SetElement(int index, const CAD::Point& p);
        CAD::Point& GetElement(int index);
        CAD::Point& operator [] (int index);
        const CAD::Point& operator [] (int index) const; //useful when the array is const
        Array operator = (const Array& source); // Assignment Operator
    private:
        CAD::Point* m_data;
        int m_size;
};
}}
#endif
