#include "Point.h"
#include<iostream>
using namespace std;

int main() {
    double x, y;
    cout << "Please input x-coordinates of the point:";
    cin >> x;
    cout << "Please input y-coordinates of the point:";
    cin >> y;
    cout << x << " " << y << endl;

    Point pp;
    pp.SetX(x);
    pp.SetY(y);
    cout << pp.ToString() << endl;
    cout << "The point coordinates is: (" << pp.GetX() << "," << pp.GetY() << ")" << endl;
}

