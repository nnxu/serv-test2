#include "Point.h"
#include <sstream>
#include <cmath>

double Point::GetX() {
    return m_x;
}

double Point::GetY() {
    return m_y;
}

double Point::SetX(double x) {
    m_x = x;
}
double Point::SetY(double y) {
    m_y = y;
}

std::string Point::ToString() {
    std::stringstream ss;
    ss << "Description:the point is (" << m_x << "," << m_y << ").";
    return ss.str();
}

double Point::DistanceOrigin() {
    return std::sqrt(m_x * m_x + m_y * m_y);
}

double Point::Distance(Point p) {
    return std::sqrt((m_x-p.m_x)*(m_x-p.m_x) + (m_y-p.m_y)*(m_y-p.m_y));
}
