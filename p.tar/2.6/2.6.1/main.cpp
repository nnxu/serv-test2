#include "Point.h"
#include "Array.h"
#include "Line.h"
#include "Circle.h"

#include<iostream>
using namespace std;
using namespace MyName::Containers;
using MyName::CAD::Line;
namespace CD = MyName::CAD;

int main() {
    Array arr(10);
    MyName::CAD::Point p(1,2.33);
    MyName::CAD::Point p2(3,5);
    arr.SetElement(2,p);
    cout << arr.GetElement(2) << endl;
    Line line(p, p2);
    cout << line << endl;
    CD::Circle circle(p, 5);
    return 0;
}

