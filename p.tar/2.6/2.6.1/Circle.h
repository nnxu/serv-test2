#ifndef _CIRCLE_H
#define _CIRCLE_H
#include "Point.h"
#include <string>
#define M_PI 3.1415926
namespace MyName { namespace CAD {

class Circle {
    public:
        Circle();
        Circle(const Point& p, double radius); //constructor
        Circle(const Circle& c); //constructor
        ~Circle();
        Point CenterPoint() const; //get center point
        Point CenterPoint(const Point& p); //set center point
        double Radius() const; //get radis
        double Radius(double radius); //set radis
        double Diameter() const; //get diameter
        double Area() const; //computer area
        double Circumference() const; //computer circmferenct
        std::string ToString() const;
        Circle& operator = (const Circle& source); // Assignment Operator
        friend ostream& operator << (ostream& os, const Circle& c); // Send to ostream
    private:
        Point m_center;
        double m_radius;
};
}}
#endif
