#include "Circle.h"
#include <sstream>
namespace MyName { namespace CAD {

Circle::Circle() {
    m_center.X(0);
    m_center.Y(0);
    m_radius = 0.00;
}

Circle::Circle(const Point& p, double radius) {
    m_center = p;
    m_radius = radius;
}

Circle::Circle(const Circle& c) {
    m_center = c.m_center;
    m_radius = c.m_radius;
}
Circle::~Circle() {
}

Point Circle::CenterPoint() const {
    return m_center;
}

Point Circle::CenterPoint(const Point& p) {
    m_center = p;
}

double Circle::Radius() const {
    return m_radius;
}
double Circle::Radius(double radius) {
    m_radius = radius;
}
double Circle::Diameter() const {
    return m_radius * 2;
}
double Circle::Area() const{
    return m_radius * M_PI * M_PI;
}
double Circle::Circumference() const{
    return m_radius * M_PI * 2;
}
std::string Circle::ToString() const {
    std::stringstream ss;
    ss << "(c-" << m_center.ToString() << ", r-" << m_radius << ")";
    return ss.str();
}

Circle& Circle::operator = (const Circle& source) {
    if(this != &source) {
        m_center = source.m_center;
        m_radius = source.m_radius;
    }
    return *this;
}

ostream& operator << (ostream& os, const Circle& c) {
    os << "(c-" << c.m_center << ", r-" << c.m_radius << ")"; 
    return os;
}
}}
