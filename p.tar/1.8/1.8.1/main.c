#include<stdio.h>

struct Article {
    int number;
    int quantity;
    char description[20];
};

void Print(const struct Article* p) {
    printf("The article number is %d\n", p->number);
    printf("Quantity is %d\n", p->quantity);
    printf("Description is %s\n", p->description);
}

int main() {
    struct Article aa = {3,100, "abcdd"};
    Print(&aa);
    return 0;
}

