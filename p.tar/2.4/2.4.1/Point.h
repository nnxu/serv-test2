#ifndef _POINT_H
#define _POINT_H
#include <string>
class Point {
    public:
        Point();
        Point(const Point& p); //constructor
        Point(double x, double y); //construcor
        ~Point();
        double X() const; //get x
        double Y() const; //get y
        //All the member function declared and defined within class are Inline by default
        double X(double x) { m_x = x; } //set y
        double Y(double y) { m_y = y; } //set x
        std::string ToString() const;

        double Distance() const; //the distance for (0,0)
        double Distance(const Point& p) const; //the distance from p

        Point operator - () const; // Negate the coordinates.
        Point operator * (double factor) const; // Scale the coordinates.
        Point operator + (const Point& p) const; // Add coordinates.
        bool operator == (const Point& p) const; // Equally compare operator
        Point& operator = (const Point& source); // Assignment Operator
        Point& operator *= (double factor); //Scale the coordinates & assign

    private:
        double m_x;
        double m_y;
};

inline double Point::X() const {
    return m_x;
}
inline double Point::Y() const {
    return m_y;
}
#endif
