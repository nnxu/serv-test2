#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include<iostream>
using namespace std;

int main() {
    Point p1(1.5, 3.9);
    Point p2(3, 4);
    Point p3 = p1 + p2;
    cout << p3.ToString() << endl;
    Point p4(p3*=2);
    cout << p4.ToString() << endl;
}

