#ifndef _LINE_H
#define _LINE_H
#include "Point.h"
#include <string>
class Line {
    public:
        Line();
        Line(const Point& sp, const Point& ep); //constructor
        Line(const Line& l); //copy constructor
        ~Line(); 
        Point SP() const; //get start point
        Point SP(const Point& sp); //set start point
        Point EP() const; //get end point
        Point EP(const Point& ep); //set end point
        std::string ToString() const; 
        double Length() const; //get length
        Line& operator = (const Line& source); // Assignment Operator
    private:
        Point m_sp; //start point
        Point m_ep; //end point

};

#endif
