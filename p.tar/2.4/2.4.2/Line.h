#ifndef _LINE_H
#define _LINE_H
#include "Point.h"
#include <string>
class Line {
    public:
        Line();
        Line(const Point& sp, const Point& ep);
        Line(const Line& l); //copy construcor
        ~Line();
        Point SP() const;
        Point SP(const Point& sp);
        Point EP() const;
        Point EP(const Point& ep);
        std::string ToString() const;
        double Length() const; //the length of line
        Line& operator = (const Line& source); // Assignment Operator
    private:
        Point m_sp; //start point
        Point m_ep; //end point

};

ostream& operator << (ostream& os, const Line& line); // Send to ostream
#endif
