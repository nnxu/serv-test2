#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include<iostream>
using namespace std;

int main() {
    Point p1(1.5, 3.9);
    Point p2(3, 5);
    cout << p1 << " " << p2<< endl;
    Line line(p1, p2);
    cout << line << endl;
    Circle c(p1, 5);
    cout << c << endl;
}

