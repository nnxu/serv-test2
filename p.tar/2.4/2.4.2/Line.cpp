#include<iostream>
#include "Line.h"

Line::Line() {
    m_sp.X(0);
    m_sp.Y(0);
    m_ep.X(0);
    m_ep.Y(0);
}

Line::Line(const Point& sp, const Point& ep) {
    m_sp = sp;
    m_ep = ep;
}

Line::Line(const Line& l) {
    m_sp = l.m_sp;
    m_ep = l.m_ep;
}
Line::~Line() {
    ;
}

Point Line::SP() const {
    return m_sp;
}
Point Line::SP(const Point& sp) {
    m_sp = sp;
}
Point Line::EP() const {
    return m_ep;
}
Point Line::EP(const Point& ep) {
    m_ep = ep;
}

std::string Line::ToString() const {
    return m_sp.ToString() + "-" + m_ep.ToString();
}
double Line::Length() const {
    return m_sp.Distance(m_ep);
}

Line& Line::operator = (const Line& source) {
    if(this != &source) {
        m_sp = source.m_sp;
        m_ep = source.m_ep;
    }
    return *this;
}

ostream& operator << (ostream& os, const Line& line) {
    os << line.ToString();
    return os;
}
