#include "Point.h"
#include<iostream>
using namespace std;

int main() {
    Point p(1.0, 1.0);
    if (p == (Point)1.0) cout << "Equal!" << endl;
    else cout << "Not equal!" << endl;
}

