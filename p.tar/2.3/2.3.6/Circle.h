#ifndef _CIRCLE_H
#define _CIRCLE_H
#include "Point.h"
#include <string>
#define M_PI 3.1415926

class Circle {
    public:
        Circle();
        Circle(const Point& p, double radius);
        Circle(const Circle& c);
        Point CenterPoint() const;
        Point CenterPoint(const Point& p);
        double Radius() const;
        double Radius(double radius);
        double Diameter() const;
        double Area() const;
        double Circumference() const;
        std::string ToString() const;

        ~Circle();
    private:
        Point m_center;
        double m_radius;
};

#endif
