#include "Point.h"
#include "Line.h"
#include<iostream>
using namespace std;

int main() {
    const Point cp(1.5, 3.9);
    //cp.X(0.3); try to change const point, compile failed
    cout << cp.X() << endl;
}

