#include "Point.h"
#include <sstream>
#include <cmath>
#include <iostream>

Point::Point() {
    std::cout << "Point default constructor \n";
}

Point::Point(const Point& p) {
    std::cout << "Point copy constructor \n";
    m_x = p.m_x;
    m_y = p.m_y;
}

Point::Point(double x, double y) {
    std::cout << "Point accept x,y coordinates constructor \n";
    m_x = x;
    m_y = y;
}

Point::~Point() {
    std::cout << "Point default destructor \n";
}

std::string Point::ToString() const {
    std::stringstream ss;
    ss << "(" << m_x << "," << m_y << ")";
    return ss.str();
}

double Point::Distance() const {
    return std::sqrt(m_x * m_x + m_y * m_y);
}

double Point::Distance(const Point& p) const {
    //p.SetX(5); try to change to const p, but compile failed! 
    return std::sqrt((m_x-p.m_x)*(m_x-p.m_x) + (m_y-p.m_y)*(m_y-p.m_y));
}
