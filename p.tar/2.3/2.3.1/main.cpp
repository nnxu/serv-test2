#include "Point.h"
#include<iostream>
using namespace std;

int main() {
    double x, y;
    cout << "Please input x-coordinates of the point:";
    cin >> x;
    cout << "Please input y-coordinates of the point:";
    cin >> y;

    Point pp;
    pp.SetX(x);
    pp.SetY(y);
    cout << pp.ToString() << endl;
    cout << "The point coordinates is: (" << pp.GetX() << "," << pp.GetY() << ")" << endl;

    Point pp2;
    pp2.SetX(5);
    pp2.SetY(6);
    cout << "The distance from (5,6) is " << pp.Distance(pp2) << endl;
    cout << "when using Distance(), the default constructor and default destructor is not the same count! Just because of the paramter of Distance" << endl;
}

