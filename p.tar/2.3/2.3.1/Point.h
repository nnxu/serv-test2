#ifndef _POINT_H
#define _POINT_H
#include <string>
class Point {
    public:
        Point();
        Point(const Point& p);
        Point(double x, double y);
        ~Point();
        double GetX();
        double GetY();
        double SetX(double x);
        double SetY(double y);
        std::string ToString();

        double DistanceOrigin();
        double Distance(Point p);

    private:
        double m_x;
        double m_y;
};

#endif
