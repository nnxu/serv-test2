#ifndef _POINT_H
#define _POINT_H
#include <string>
class Point {
    public:
        Point();
        Point(const Point& p);
        Point(double x, double y);
        ~Point();
        double X();
        double Y();
        double X(double x);
        double Y(double y);
        std::string ToString();

        double Distance();
        double Distance(const Point& p);

    private:
        double m_x;
        double m_y;
};

#endif
