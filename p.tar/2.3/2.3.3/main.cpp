#include "Point.h"
#include<iostream>
using namespace std;

int main() {
    double x, y;
    cout << "Please input x-coordinates of the point:";
    cin >> x;
    cout << "Please input y-coordinates of the point:";
    cin >> y;

    Point pp(x,y);
    cout << pp.ToString() << endl;
    cout << "The point coordinates is: (" << pp.X() << "," << pp.Y() << ")" << endl;

    Point pp2(5,6);
    cout << "The distance from (5,6) is " << pp.Distance(pp2) << endl;
}

