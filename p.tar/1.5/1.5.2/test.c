#include<stdio.h>

int factor(int n) {
    if(n == 1) {
        return n;
    } else {
        return n * factor(n-1);
    }
}
int main() {
    int result = factor(4);
    printf("%d\n", result);
    return 0;
}
