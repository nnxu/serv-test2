#include<stdio.h>

double minus(double a, double b) {
    return a-b;
    printf("%10.2f", a-b);
}
int main() {
    double c = minus(2.55,9.89);
    printf("%10.2f\n", c);
    return 0;
}
