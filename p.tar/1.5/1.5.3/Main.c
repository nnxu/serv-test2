#include<stdio.h>

int main() {
    print();
    return 0;
}
