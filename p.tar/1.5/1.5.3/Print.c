#include<stdio.h>

void print() {
    printf("hello world\n");
}
