#include<stdio.h>


void print(n) {
    if(n<0) {
        putchar('-');
        n *= -1;
    }
    if(n / 10 == 0) {
        putchar(n+'0');
    } else {
        print(n/10);
        putchar(n%10 + '0');
    }
}
int main() {
    int n;
    printf("Please input the number: ");
    scanf("%d", &n);
    print(n);
    putchar('\n');
    return 0;
}
