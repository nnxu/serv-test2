#include<stdio.h>
int main() {
    double fah, cel;
    printf("Celsius       Fahrenheit\n");
    for(cel = 0; cel <= 19; ++cel) {
        fah = cel * 9 / 5 + 32;
        printf("%10.1f     %10.1f\n", cel, fah);
    }
    return 0;
}
