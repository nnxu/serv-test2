#include <stdio.h>
#include <stdbool.h>
int main()
{
    char c = 0;
    int character = 0;
    int line = 0;
    int word = 0;
    bool newword = true;
    c =  getchar();
    if(c<4) {
        printf("characters:%d  lines:%d  words:%d\n", character, line, word);
        return 0;
    }
    do {
        ++character;
        switch(c) {
            case '\n':
                ++line;
                if(!newword) {
                    newword = true;
                }
                break;
            case ' ':
                if(!newword) {
                    newword = true;
                }
                break;
            default:
                if(newword) {
                    ++word;
                    newword = false;
                }
                break;
        }
    } while((c = getchar()) >4);
    printf("characters:%d  lines:%d  words:%d\n", character, line, word);
    return 0;
}
