#include<stdio.h>
int main() {
    double fah, cel;
    printf("Fahrenheit        Celsius\n");
    for(fah = 0; fah <= 300; fah+=20) {
        cel = (fah - 32) * 5 / 9;
        printf("%10.1f     %10.1f\n", fah, cel);
    }
    return 0;
}
