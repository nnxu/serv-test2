#include <stdio.h>
#include <stdbool.h>

int main()
{
    char c = 0;
    int character = 0;
    int line = 0;
    int word = 0;
    bool newword = true;
    while((c = getchar()) > 4) {
        ++character;
        if(newword && c !='\n' && c!=' ') {
            ++word;
            newword = false;
        } else if(!newword && (c=='\n' || c==' ')) {
            newword = true;
        }
        if(c == '\n') {
            ++line;
        }
    }
    printf("characters:%d  lines:%d  words:%d\n", character, line, word);
    return 0;
}
