#include<stdio.h>
int main() {
    char c;
    int n0=0, n1=1, n2=0, n3=0, n4=0;
    int other = 0;
    while((c=getchar()) != EOF) {
        switch(c) {
            case '0':
                ++n0;
                break;
            case '1':
                ++n1;
                break;
            case '2':
                ++n2;
                break;
            case '3':
                ++n3;
                break;
            case '4':
                ++n4;
                break;
            default:
                ++other;
                break;
        }
    }
    printf("The number 0 appears %d times\n", n0);
    printf("The number 1 appears %d times\n", n1);
    printf("The number 2 appears %d times\n", n2);
    printf("The number 3 appears %d times\n", n3);
    printf("The number 4 appears %d times\n", n4);
    return 0;
}
