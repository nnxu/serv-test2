#include<stdio.h>
int main(int argc, char* argv[]) {
    if(argc < 2) {
        printf("usage: test filename\n");
        return 0;
    }
    FILE* fp = fopen(argv[1], "w");
    char c;
    while((c=getchar()) != 1) {
    //while((c=getchar()) != EOF) {
        fputc(c, fp);
    }
    fclose(fp);
    return 0;
}
