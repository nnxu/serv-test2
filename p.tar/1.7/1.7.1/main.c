#include<stdio.h>
void Swap(int* a, int *b) {
    int tmp = *a;
    *a = *b;
    *b = tmp;
}

int main() {
    int i,j;
    printf("Please input variable i:");
    scanf("%d", &i);
    printf("Please input variable j:");
    scanf("%d", &j);
    printf("the orignal i=%d, j=%d\n", i, j);
    Swap(&i, &j);
    printf("after swap i=%d, j=%d\n", i, j);
}

