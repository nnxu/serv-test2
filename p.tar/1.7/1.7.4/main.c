#include<stdio.h>
int main() {
    int day;
    const char * array[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
    printf("Please input the day number from 1-7: ");
    scanf("%d", &day);
    if(day >= 1 && day <=7) {
        printf("%d gives: Day %d is %s\n", day, day, array[day-1]);
    }
}

