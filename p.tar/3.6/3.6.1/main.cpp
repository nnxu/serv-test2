#include "Point.h"
#include "Array.h"
#include "Line.h"
#include "Shape.h"

#include<iostream>
using namespace std;
using namespace MyName::CAD;
using namespace MyName::Containers;

int main() {
    Array arr(5);
    try {
        Point p = arr.GetElement(6);
    } catch(int e) {
        cout << "find exception: " << e << endl;
    }
    return 0;
}

