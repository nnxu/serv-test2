#ifndef _OUTOFBOUNDSEXCEPTION_H
#define _OUTOFBOUNDSEXCEPTION_H
#include <sstream>
#include <string>
#include "ArrayException.h"
class OutOfBoundsException : public ArrayException {
    public:
        OutOfBoundsException(int e) : m_e(e) { }
        std::string GetMessage();
    private:
        int m_e;
};

std::string OutOfBoundsException::GetMessage() {
    std::stringstream ss;
    ss << "The given index " << m_e << " is out of bounds";
    return ss.str();
}
#endif
