#ifndef _ARRAYEXCEPTION_H
#define _ARRAYEXCEPTION_H
#include <string>
class ArrayException {
    public:
        virtual std::string GetMessage() = 0;
    private:
};
#endif
