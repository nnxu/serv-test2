#include "Point.h"
#include "Array.h"
#include "Line.h"
#include "Shape.h"
#include "ArrayException.h"
#include<iostream>
using namespace std;
using namespace MyName::CAD;
using namespace MyName::Containers;

int main() {
    Array arr(5);
    try {
        Point p = arr.GetElement(6);
    } catch(ArrayException& e) {
        cout << e.GetMessage() << endl;
    }
    return 0;
}

