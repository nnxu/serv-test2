#include <list>
#include <vector>
#include<iostream>
#include <map>
using namespace std;
int main() {
    list<double> mylist;
    mylist.push_back(5.1);
    mylist.push_back(8.2);
    mylist.push_back(10.3);

    cout << mylist.front() << " " << mylist.back() << endl;

    vector<double> myvector;
    myvector.push_back(0);
    myvector.push_back(5);
    for(int i =0; i < myvector.size(); ++i) {
        cout << myvector[i] << endl;
    }

    map<string, double> mymap;
    mymap["aa"] = 5.00;
    mymap["bb"] = 6.00;
    cout << mymap["bb"] << endl;

    return 0;
}

