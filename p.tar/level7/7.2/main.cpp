#include <list>
#include <vector>
#include<iostream>
#include <map>
using namespace std;

template<class T>
double Sum(const T& in) {
    double result = 0.0;
    for(typename T::const_iterator it = in.begin(); it != in.end(); ++it) {
        result += *it;
    }
    return result;
}
template<class T>
double Sum(T begin, T end) {
    double result = 0.0;
    for(T it = begin; it != end; ++it) {
        result += *it;
    }
    return result;
}

int main() {
    list<double> mylist;
    mylist.push_back(5.1);
    mylist.push_back(8.2);
    mylist.push_back(10.3);

    cout << Sum(mylist) << endl;

    vector<double> myvector;
    myvector.push_back(0);
    myvector.push_back(5);
    cout << Sum(myvector) << endl;
    cout << Sum(myvector.begin(), myvector.end()) << endl;

    map<string, double> mymap;
    mymap["aa"] = 5.00;
    mymap["bb"] = 6.00;
    cout << mymap["bb"] << endl;

    return 0;
}

