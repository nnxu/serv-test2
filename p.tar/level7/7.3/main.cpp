#include <list>
#include <vector>
#include<iostream>
#include <map>
#include <algorithm>
using namespace std;

bool isSmaller(double i) {
    return i < 10.00;
}

int main() {
    list<double> mylist;
    mylist.push_back(5.1);
    mylist.push_back(8.2);
    mylist.push_back(10.3);
    cout <<  count_if(mylist.begin(), mylist.end(), isSmaller) << endl;


    vector<double> myvector;
    myvector.push_back(0);
    myvector.push_back(5);

    map<string, double> mymap;
    mymap["aa"] = 5.00;
    mymap["bb"] = 6.00;

    return 0;
}

