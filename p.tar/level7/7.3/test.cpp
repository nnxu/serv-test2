using namespace std;

int main() {
    mymap["bb"] = 6.00;

    return 0;
}

