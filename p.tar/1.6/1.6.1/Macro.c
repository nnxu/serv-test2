#include<stdio.h>
#include "Defs.h"

int main() {
    int a,b;
    printf("Please input variable a:");
    scanf("%d", &a);
    printf("Please input variable b:");
    scanf("%d", &b);
    PRINT1(a);
    PRINT2(a, b);
    return 0;
}

