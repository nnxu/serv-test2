#ifndef _DEFS_H
#define _DEFS_H
#define PRINT1(a) printf("%d\n",a)
#define PRINT2(a,b) printf("%d %d\n",a,b)
#endif
