#include<stdio.h>
#include "Defs.h"

int main() {
    int x,y,z;
    printf("Please input variable x:");
    scanf("%d", &x);
    printf("Please input variable y:");
    scanf("%d", &y);
    printf("Please input variable z:");
    scanf("%d", &z);
    PRINT1(MAX2(x,y));
    PRINT1(MAX3(x,y,z));
    return 0;
}

