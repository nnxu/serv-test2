#ifndef _DEFS_H
#define _DEFS_H

#define PRINT1(a) printf("%d\n",a)
#define PRINT2(a,b) printf("%d %d\n",a,b)
#define MAX2(x,y) (x>y?x:y)
#define MAX3(x,y,z) MAX2(MAX2(x,y),z)

#endif
