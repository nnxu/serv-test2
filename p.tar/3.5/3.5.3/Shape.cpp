#include<iostream>
#include "Shape.h"
#include <stdlib.h>
#include <sstream>
using namespace std;
namespace MyName { namespace CAD { 

Shape::Shape() {
    m_id = rand();
}
Shape::~Shape() {
    cout << "Shape destructor" << endl;
}

Shape& Shape::operator = (const Shape& source) {
    if(this != &source) {
        m_id = source.m_id;
    }
    return *this;
}

std::string Shape::ToString() const {
    stringstream ss;
    ss << "ID: " << m_id;
    return ss.str();
}
 int Shape::ID() const {
     return m_id;
 }

}}

