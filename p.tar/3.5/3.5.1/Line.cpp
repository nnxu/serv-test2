#include<iostream>
#include "Line.h"
namespace MyName { namespace CAD {

Line::~Line() {
    ;
}

Point Line::SP() const {
    return m_sp;
}
Point Line::SP(const Point& sp) {
    m_sp = sp;
}
Point Line::EP() const {
    return m_ep;
}
Point Line::EP(const Point& ep) {
    m_ep = ep;
}

std::string Line::ToString() const {
    return m_sp.ToString() + "-" + m_ep.ToString();
}
double Line::Length() const {
    return m_sp.Distance(m_ep);
}

Line& Line::operator = (const Line& source) {
    if(this != &source) {
        Shape::operator=(source);
        m_sp = source.m_sp;
        m_ep = source.m_ep;
    }
    return *this;
}

ostream& operator << (ostream& os, const Line& line) {
    os << line.m_sp << "-" << line.m_ep;
    return os;
}
}}
