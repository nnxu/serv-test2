#include "Point.h"
#include "Array.h"
#include "Line.h"
#include "Shape.h"
//#include "Circle.h"

#include<iostream>
using namespace std;
using namespace MyName::CAD;

int main() {
    Shape s;// Create shape.
    Point p(10, 20);// Create point.
    Line l(Point(1,2), Point(3, 4)); // Create line.

    cout<<s.ToString()<<endl;// Print shape. ID: 846930886
    cout<<p.ToString()<<endl;// Print point. (10,20)
    cout<<l.ToString()<<endl;// Print line  (1,2)-(3,4)

    cout<<"Shape ID: "<<s.ID()<<endl; // ID of the shape.
    cout<<"Point ID: "<<p.ID()<<endl; // ID of the point. Does this work? Yes
    cout<<"Line ID: "<<l.ID()<<endl; // ID of the line. Does this work? Yes

    Shape* sp; // Create pointer to a shape variable.
    sp=&p; // Point in a shape variable. Possible?
    cout<<sp->ToString()<<endl;// What is printed? (10,20) 

    // Create and copy Point p to new point.
    Point p2;
    p2=p;
    cout<<p2<<", "<<p2.ID()<<endl; // Is the ID copied if you do not call
                                  // the base class assignment in point?
                                  // Yes (10,20), 846930886
    return 0;
}

