
#ifndef _POINT_H
#define _POINT_H
#include <string>
#include <iostream>
#include "Shape.h"
using namespace std;

namespace MyName { namespace CAD { 
class Point : public Shape {
    public:
        Point() : Shape(), m_x(0), m_y(0) { }
        Point(const Point& p): Shape(), m_x(p.m_x), m_y(p.m_y) { }
        Point(double x, double y) : Shape(), m_x(x), m_y(y) { }
        explicit Point(double x) : Shape(), m_x(x), m_y(x) { }
        ~Point();
        double X() const;
        double Y() const;
        //All the member function declared and defined within class are Inline by default
        double X(double x) { m_x = x; }
        double Y(double y) { m_y = y; }
        std::string ToString() const;

        double Distance() const;
        double Distance(const Point& p) const;

        Point operator - () const; // Negate the coordinates.
        Point operator * (double factor) const; // Scale the coordinates.
        Point operator + (const Point& p) const; // Add coordinates.
        bool operator == (const Point& p) const; // Equally compare operator
        Point& operator = (const Point& source); // Assignment Operator
        Point& operator *= (double factor); //Scale the coordinates & assign
        
        friend ostream& operator << (ostream& os, const Point& p); // Send to ostream
    private:
        double m_x;
        double m_y;
};

inline double Point::X() const {
    return m_x;
}
inline double Point::Y() const {
    return m_y;
}

}}
#endif


