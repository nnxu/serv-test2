#ifndef _LINE_H
#define _LINE_H
#include "Point.h"
#include "Shape.h"
#include <string>
namespace MyName { namespace CAD { 
class Line : public Shape {
    public:
        Line() : Shape(), m_sp(0,0), m_ep(0,0) { }
        Line(const Point& sp, const Point& ep) : Shape(), m_sp(sp), m_ep(ep) { }
        Line(const Line& l) : Shape(), m_sp(l.m_sp), m_ep(l.m_ep) { }
        ~Line();
        Point SP() const;
        Point SP(const Point& sp);
        Point EP() const;
        Point EP(const Point& ep);
        std::string ToString() const;
        double Length() const;
        Line& operator = (const Line& source); // Assignment Operator

        friend ostream& operator << (ostream& os, const Line& line); // Send to ostream
    private:
        Point m_sp; //start point
        Point m_ep; //end point

};
}}
#endif
