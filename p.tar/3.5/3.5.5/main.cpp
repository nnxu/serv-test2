#include "Point.h"
#include "Array.h"
#include "Line.h"
#include "Shape.h"

#include<iostream>
using namespace std;
using namespace MyName::CAD;

int main() {
    Shape* shapes[2];
    shapes[0]=new Line(Point(1.0, 2.5), Point(3.4, 5.2));
    shapes[1]=new Point;
    for (int i=0; i!=2; i++) shapes[i]->Print();
    for (int i=0; i!=2; i++) delete shapes[i];
    return 0;
}

